# -*- coding: utf-8 -*-
"""
Created on Sun Sep  3 16:20:06 2017

@author: Test
"""

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# Import dataset
dataset = pd.read_csv('salary_Data.csv')
x= dataset.iloc[:, :-1].values
y= dataset.iloc[:, 3].values
              
#Imputing the missing values
from sklearn.preprocessing import Imputer
imputer = Imputer(missing_values='NaN', strategy="mean", axis=0 )
imputer= imputer.fit(x[:, 1:]) 
x[:,1:3] =imputer.transform(x[:,1:3])  
xsdvd      