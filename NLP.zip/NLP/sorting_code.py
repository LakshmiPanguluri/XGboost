import sys
A = [64, 25, 12, 22, 11]

#selection sort
for i in range(0, len(A)-1):
    for j in range(i+1, len(A)):
        if A[i]<=A[j]:
            continue
        else:
            A[i], A[j]=A[j],A[i]

print(A)

        
        