from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener


#consumer key, consumer secret, access token, access secret.
ckey="AuDTUJWmvOBW0GRdMIkBxeDB6"
csecret="lTHfwKoOP0AsFFii2ANejfrwcZIHkotZlyQQaALLR9quPVx1Rr"
atoken="1054989368-WNx8o1PXnaQT6ODxjawGbnoCzo6IOSgdmsHiwRq"
asecret="dJGwipEbSqMDqKKMzxSc0jcqC5wRsbZll08IYjxcJTDo5"

class listener(StreamListener):

    def on_data(self, data):
        print(data)
        return(True)

    def on_error(self, status):
        print(status)

auth = OAuthHandler(ckey, csecret)
auth.set_access_token(atoken, asecret)

twitterStream = Stream(auth, listener())
twitterStream.filter(track=["car"])


tweet = ascii(all_data["text"])

from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import json
import sentiment_mod as s

#consumer key, consumer secret, access token, access secret.
ckey="AuDTUJWmvOBW0GRdMIkBxeDB6"
csecret="lTHfwKoOP0AsFFii2ANejfrwcZIHkotZlyQQaALLR9quPVx1Rr"
atoken="1054989368-WNx8o1PXnaQT6ODxjawGbnoCzo6IOSgdmsHiwRq"
asecret="dJGwipEbSqMDqKKMzxSc0jcqC5wRsbZll08IYjxcJTDo5"

from twitterapistuff import *

class listener(StreamListener):
    def on_data(self, data):
        all_data = json.loads(data)
        tweet = ascii(all_data["text"])
        sentiment_value, confidence = s.sentiment(tweet)
        print(tweet, sentiment_value, confidence)
        if confidence*100 >= 80:
            output = open("twitter-out.txt","a")
            output.write(tweet)
            output.write(sentiment_value)
            output.write(str(confidence))
            output.write('\n')
            output.close()
        return True
    def on_error(self, status):
        print(status)

auth = OAuthHandler(ckey, csecret)
auth.set_access_token(atoken, asecret)

twitterStream = Stream(auth, listener())
twitterStream.filter(track=["happy"])